setwd("D:\\Desktop\\PS - IT2120\\IT24101596_PS_Lab_06")

##PART 01
## Random Variable X has binomial distribution with n=44 and p= 0.92

##PART 02
dbinom(40,44,0.92)

##PART 03
pbinom(35,44,0.92,lower.tail=TRUE)

##PART 04
1 - pbinom(37,44,0.92,lower.tail=TRUE)
pbinom(37,44,0.92, lower.tail=FALSE)

##PART  05
pbinom(42,44,0.92, lower.tail = TRUE)-pbinom(39,44,0.92,lower.tail=TRUE)

##Question 02
##PART 01

##Number of babies born in a hospital on a given day

##PART 02
##Poisson distribution
##Random variable X has poisson distribution with lambda= 5

##PART 03
dpois(6,5)

##PART 04
ppois(6,5, lower.tail = FALSE)           

##EXERCISE 
##PART 01
##i)
##Binomial distribution
##Random Variable X has binomial distribution with n=50 and p=0.85

##ii)
pbinom(46,50,0.85,lower.tail=FALSE)

##PART 02
##I)
##Random variable X defines number of calls received in one hour

##II)
##Random variable X has poisson distribution with lambda=12

##III)
dpois(15,12)